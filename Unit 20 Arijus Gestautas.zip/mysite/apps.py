from django.apps import AppConfig


class mysiteConfig(AppConfig):
    name = 'mysite'
